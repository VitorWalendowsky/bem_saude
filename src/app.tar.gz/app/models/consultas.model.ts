export interface ConsultasResponseModel {
    id: string;
    nomePaciente: string;
    cpfPaciente: string;
    telefonePaciente: string;
    dataConsulta: string;
    status: boolean;
}

export interface ConsultaCriarRequestModel {
    pacienteId: string;
    dataConsulta: string;
    observacoes: string;
}

export interface ConsultaEditarRequestModel {
    dataConsulta: string;
    observacoes: string;
    status: boolean;
}

export interface ConsultaPesquisaResponseModel {
    id: string;
    nomePaciente: string;
    cpfPaciente: string;
    telefonePaciente: string;
    dataConsulta: string;
    observacoes: string;
    status: boolean;
}
