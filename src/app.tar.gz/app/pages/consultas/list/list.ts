import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConsultasResponseModel } from '../../models/consulta.model';

@Component({
  selector: 'app-list-consultas',
  templateUrl: './list-consultas.component.html'
})
export class ListConsultasComponent implements OnInit {

  consultas: ConsultasResponseModel[] = [];
  consultaForm!: FormGroup;

  visible = false;
  editando = false;
  consultaId!: string;

  pesquisa = '';
  filtros = [
    { label: 'Nome', value: 'nomePaciente' },
    { label: 'CPF', value: 'cpfPaciente' },
    { label: 'Telefone', value: 'telefonePaciente' }
  ];
  filtroSelecionado = this.filtros[0];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.criarFormulario();
    this.listar();
  }

  criarFormulario(): void {
    this.consultaForm = this.fb.group({
      nomePaciente: [{ value: '', disabled: true }],
      cpfPaciente: [{ value: '', disabled: true }],
      telefonePaciente: [{ value: '', disabled: true }],
      dataConsulta: ['', Validators.required],
      observacoes: [''],
      status: [true, Validators.required]
    });
  }

  listar(): void {
    // MOCK – substituir por service
    this.consultas = [
      {
        id: '1',
        nomePaciente: 'Maria Souza',
        cpfPaciente: '123.456.789-00',
        telefonePaciente: '(48) 99999-9999',
        dataConsulta: '2026-02-10',
        status: true
      }
    ];
  }

  showDialog(): void {
    this.editando = false;
    this.consultaForm.reset({ status: true });
    this.visible = true;
  }

  editar(consulta: ConsultasResponseModel): void {
    this.editando = true;
    this.consultaId = consulta.id;

    this.consultaForm.patchValue(consulta);
    this.visible = true;
  }

  salvar(): void {
    if (this.consultaForm.invalid) return;

    const payload = this.consultaForm.getRawValue();
    console.log(this.editando ? 'Editar' : 'Criar', payload);

    this.visible = false;
    this.consultaForm.reset();
    this.listar();
  }

  cancelar(): void {
    this.visible = false;
    this.consultaForm.reset();
  }

  excluir(id: string): void {
    console.log('Excluir consulta', id);
    this.listar();
  }
}
